#!/usr/bin/env python3
import promt
def main():
     print("Welcome to the Brain Games!")
     
import prompt

def welcome_user:
	name = prompt.string('May I have your name? ')


if __name__ == '__main__':
     main()
