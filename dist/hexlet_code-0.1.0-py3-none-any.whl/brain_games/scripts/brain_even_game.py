#!/usr/bin/env python3
import random
from brain_games.scripts.brain_games import main
from brain_games.scripts.brain_even import play_game

if __name__ == '__main__':
    main()
    play_game()