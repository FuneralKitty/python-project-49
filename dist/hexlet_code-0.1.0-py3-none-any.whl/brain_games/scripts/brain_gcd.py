from brain_games.engines.brain_gcd_logic import play_game


def main():
    print("Welcome to the Brain Games!")
    play_game()


if __name__ == '__main__':
    main()
