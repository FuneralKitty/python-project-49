<a href="https://codeclimate.com/github/FuneralKitty/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/0ffafb39f5ea1b073398/maintainability" /></a>


brain calculator https://asciinema.org/a/bUgBoUDiBPQrn7vJiC0LrkQAA
brain gcd https://asciinema.org/a/4To5aCraTXEdfky1jvu2AIJDF
brain progression https://asciinema.org/a/G7qlVbO2junvGorqO0LiWlNvl
brain prime https://asciinema.org/a/uuRC3VVCnitn9NPC1c3vBHdKD
brain even


