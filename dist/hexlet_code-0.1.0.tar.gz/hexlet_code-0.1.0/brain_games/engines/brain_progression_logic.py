"""import random
from brain_games.engines.cli import welcome_user 
from brain_games.engines.engine import (
    check_even_num,
    congratulation,
    get_user_response,
    print_question,
    print_correct_answer,
    print_wrong_answer,
)


def play_game():
    """